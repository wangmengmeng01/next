module.exports = {
  launch: {
    headless: false,
    defaultViewport: {
      width: 375,
      height: 667,
      deviceScaleFactor: 2,
      isMobile: true,
      hasTouch: true
    }
  }
}