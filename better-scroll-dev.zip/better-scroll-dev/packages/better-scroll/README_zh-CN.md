# better-scroll

具备完整插件能力的 BetterScroll，不用关心各种插件注册的细节。

## 使用

```js
import BScroll from 'better-scroll'

const bs = new BScroll('.wrapper', {
  pullUpLoad: true,
  scrollbar: true,
  pullDownRefresh: true
  // and so on
})
```
