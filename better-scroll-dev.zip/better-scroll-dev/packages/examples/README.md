# examples

BetterScroll example in different Vue scenarios.

[vue demo](https://better-scroll.github.io/examples/#/)
