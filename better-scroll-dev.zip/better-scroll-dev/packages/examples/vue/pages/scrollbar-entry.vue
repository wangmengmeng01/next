<template>
  <scroll-bar />
</template>

<script>
import ScrollBar from 'vue-example/components/scrollbar/default.vue'
export default {
  components: {
    ScrollBar
  }
}
</script>

<style lang="stylus">

</style>