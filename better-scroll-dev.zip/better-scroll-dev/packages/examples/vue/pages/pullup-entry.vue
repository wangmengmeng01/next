<template>
  <pullup />
</template>

<script>
import Pullup from 'vue-example/components/pullup/default.vue'
export default {
  components: {
    Pullup
  }
}
</script>

<style lang="stylus">

</style>