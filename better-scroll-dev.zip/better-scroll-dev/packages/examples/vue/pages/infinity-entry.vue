<template>
  <infinity />
</template>

<script>
import Infinity from 'vue-example/components/infinity/default.vue'
export default {
  components: {
    Infinity
  }
}
</script>

<style lang="stylus">

</style>