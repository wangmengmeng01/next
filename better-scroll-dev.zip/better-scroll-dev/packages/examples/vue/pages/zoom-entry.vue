<template>
  <zoom />
</template>

<script type="text/ecmascript-6">
  import Zoom from 'vue-example/components/zoom/default.vue'
  export default {
    components: {
      Zoom
    }
  }
</script>
