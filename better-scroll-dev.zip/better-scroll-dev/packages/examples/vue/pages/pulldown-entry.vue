<template>
  <pull-down />
</template>

<script>
import PullDown from 'vue-example/components/pulldown/default.vue'
export default {
  components: {
    PullDown
  }
}
</script>

<style lang="stylus">

</style>