export const style = {
  transform: 'transform',
  transition: 'transition',
  transitionTimingFunction: 'transitionTimingFunction',
  transitionDuration: 'transitionDuration',
  transitionDelay: 'transitionDelay',
  transformOrigin: 'transformOrigin',
  transitionEnd: 'transitionEnd'
}
