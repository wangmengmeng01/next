# @better-scroll/shared-utils

shared-utils for BetterScroll.
