---
home: true
heroText: BetterScroll 2.x
actionText: 快速上手 →
actionLink: /zh-CN/guide/
features:
- title: 优雅的滚动
  details: 为移动端（已支持 PC）各种滚动场景提供丝滑的滚动效果。
- title: 零依赖
  details: 基于原生 JS 实现的，不依赖任何框架。完美运用于 Vue、React 等 MVVM 框架。
- title: 扩展灵活
  details: 提供了插件机制，便于对基础滚动进行功能扩展。
footer: MIT Licensed | Copyright © 2018-present ustbhuangyi
---
