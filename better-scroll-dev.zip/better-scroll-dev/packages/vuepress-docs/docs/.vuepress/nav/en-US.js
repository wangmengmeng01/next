module.exports = [
  { text: 'Guide', link: '/en-US/guide/' },
  { text: 'Plugin', link: '/en-US/plugins/' },
  { text: 'FAQ', link: '/en-US/FAQ/' },
  { text: 'GitHub', link: 'https://github.com/ustbhuangyi/better-scroll'},
  { text: 'Discuss', link: 'https://github.com/ustbhuangyi/better-scroll/issues'}
]
