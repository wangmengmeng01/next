module.exports = [
  { text: '指南', link: '/zh-CN/guide/' },
  { text: '插件', link: '/zh-CN/plugins/' },
  { text: '常见问题', link: '/zh-CN/FAQ/' },
  { text: 'GitHub', link: 'https://github.com/ustbhuangyi/better-scroll'},
  { text: '讨论', link: 'https://github.com/ustbhuangyi/better-scroll/issues'}
]
