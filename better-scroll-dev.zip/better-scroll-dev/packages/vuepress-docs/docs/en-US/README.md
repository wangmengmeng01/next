---
home: true
heroText: BetterScroll 2.x
actionText: Getting Started →
actionLink: /en-US/guide/
features:
- title: Smooth scrolling effect
  details:  Aimed at solving scrolling circumstances on the mobile side (PC supported already).
- title: Zero dependence
  details: Based on native JS implementation, it does not depend on any framework. Perfect for Vue, React and other MVVM frameworks.
- title: Plugin support
  details: Plugin support
footer: MIT Licensed | Copyright © 2018-present ustbhuangyi
---
