const TOMBSTONE_HEIGHT = 37 // 元素默认的高度

const WRAPPER_HEIGHT = 370 // 滚动窗口的高度

const VISIBLE_CNT = 10 // 滚动窗口内能显示的元素

export { TOMBSTONE_HEIGHT, WRAPPER_HEIGHT, VISIBLE_CNT }
