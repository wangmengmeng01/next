export enum Probe {
  Default,
  Throttle,
  Normal,
  Realtime
}
