export enum MouseButton {
  Left,
  Middle,
  Right
}
