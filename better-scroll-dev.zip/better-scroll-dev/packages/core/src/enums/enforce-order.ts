export enum EnforceOrder {
  Pre = 'pre',
  Post = 'post'
}
