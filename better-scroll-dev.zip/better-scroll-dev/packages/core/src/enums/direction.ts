export enum Direction {
  Positive = 1, // bottom to top and right to left
  Negative = -1, // top to bottom and left to right
  Default = 0
}
