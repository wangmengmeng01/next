export enum EventType {
  Touch = 1,
  Mouse = 2
}
