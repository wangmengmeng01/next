# @better-scroll/core

[中文文档](https://github.com/ustbhuangyi/better-scroll/blob/master/packages/core/README_zh-CN.md)

core scroll from BetterScroll.

## Usage

```js
import BScroll from '@better-scroll/core'

const bs = new BScroll('.wrapper', {/* ... */})
```
