# @better-scroll/core

核心滚动，实现基础的列表滚动效果。

## 使用

```js
import BScroll from '@better-scroll/core'

const bs = new BScroll('.wrapper', {/* ... */})
```
