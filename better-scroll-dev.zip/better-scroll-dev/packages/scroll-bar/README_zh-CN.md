# @better-scroll/scroll-bar

一个优雅美丽的滚动条.

## 使用

```js
import BScroll from '@better-scroll/core'
import Scrollbar from '@better-scroll/scroll-bar'
BScroll.use(Scrollbar)

const bs = new BScroll('.wrapper', {
  scrollbar: true
})
```
