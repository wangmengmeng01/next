export enum Direction {
  Horizontal = 'horizontal',
  Vertical = 'vertical'
}
