describe('renderer: component', () => {
  test.todo('should work')

  test.todo('shouldUpdateComponent')

  test.todo('componentProxy')

  test.todo('componentProps')

  test.todo('componentSlots')
})
