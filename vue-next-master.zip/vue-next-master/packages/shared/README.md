# @vue/shared

Utility functions and constants shared across packages. This package itself is private and never published. It is inlined into other packages during build - rollup's tree-shaking ensures that only functions used by the importing package are included.
